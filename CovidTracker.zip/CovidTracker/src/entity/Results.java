package entity;

import enums.ResultType;

public class Results {
    Long userId;
    Long adminId;
	ResultType type;

    public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getAdminId() {
		return adminId;
	}
	public Results(Long userId, Long adminId, ResultType type) {
		super();
		this.userId = userId;
		this.adminId = adminId;
		this.type = type;
	}
	public void setAdminId(Long adminId) {
		this.adminId = adminId;
	}
	public ResultType getType() {
		return type;
	}
	public void setType(ResultType type) {
		this.type = type;
	}
    
    
}
