package entity;

import enums.ZoneType;

public class Zone {
     ZoneType zoneType;
     int noOfCases;
//	public Address getAddress() {
//		return address;
//	}
//	public void setAddress(Address address) {
//		this.address = address;
//	}
	public ZoneType getZoneType() {
		return zoneType;
	}
	public void setZoneType(ZoneType zoneType) {
		this.zoneType = zoneType;
	}
	public int getNoOfCases() {
		return noOfCases;
	}
	public void setNoOfCases(int noOfCases) {
		this.noOfCases = noOfCases;
	}
     
}
