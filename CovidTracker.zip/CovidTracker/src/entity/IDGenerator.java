package entity;

public class IDGenerator {
   private static Long id;

public static Long getId() {
	id++;
	return id;
}

public static void setId(Long id) {
	IDGenerator.id = id;
}
   
   
}
