package entity;

public class BaseUser {

	Long userId;
	String name;
	String mobileNo;
//	Address address;
	String pincode;
	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public Long getUserId() {
		return userId;
	}
	
	public BaseUser() {
		
	}
	public BaseUser(String name, String mobileNo,String pincode) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		this.pincode = pincode;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
//	public Address getAddress() {
//		return address;
//	}
//	public void setAddress(Address address) {
//		this.address = address;
//	}
}
