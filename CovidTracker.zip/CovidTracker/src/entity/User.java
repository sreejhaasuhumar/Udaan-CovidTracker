package entity;

import enums.RiskPercentage;
import enums.Symptoms;

public class User extends BaseUser {
	
	public User(String name, String mobileNo,String pincode) {
		super(name, mobileNo, pincode);
	}
	public User() {
		// TODO Auto-generated constructor stub
	}
	boolean travelHistory;
	public boolean isTravelHistory() {
		return travelHistory;
	}
	public void setTravelHistory(boolean travelHistory) {
		this.travelHistory = travelHistory;
	}
	public boolean isContactwithCovidPatient() {
		return contactwithCovidPatient;
	}
	public void setContactwithCovidPatient(boolean contactwithCovidPatient) {
		this.contactwithCovidPatient = contactwithCovidPatient;
	}
	public RiskPercentage getRiskPercentage() {
		return riskPercentage;
	}
	public void setRiskPercentage(RiskPercentage riskPercentage) {
		this.riskPercentage = riskPercentage;
	}
	public Symptoms getSymptoms() {
		return symptoms;
	}
	public void setSymptoms(Symptoms symptoms) {
		this.symptoms = symptoms;
	}
	boolean contactwithCovidPatient;	
	RiskPercentage riskPercentage;
	Symptoms symptoms;

	
	

}
