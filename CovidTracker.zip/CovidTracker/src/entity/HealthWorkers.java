package entity;

import java.util.Map;

public class HealthWorkers extends BaseUser{

	Map<User,String> testResult;
	
	public Map<User, String> getTestResult() {
		return testResult;
	}

	public void setTestResult(Map<User, String> testResult) {
		this.testResult = testResult;
	}

	public HealthWorkers(String name, String mobileNo,String pincode) {
		super(name, mobileNo, pincode);
	}
	
	public HealthWorkers() {
	}
	

}
