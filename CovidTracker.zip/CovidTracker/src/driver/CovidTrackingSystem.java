package driver;

import java.util.Scanner;

import service.CovidTrackerServiceImpl;

public class CovidTrackingSystem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CovidTrackerServiceImpl service=new CovidTrackerServiceImpl();
		Scanner s=new Scanner(System.in);
//		While(true)
//		{
//		String[] input=s.next().split("/");
//		String command=input[0]; 
//		switch(command)
//		{
//		case "registerUser":
//		{
//			String name=input[1];
//			String phone=input[2];
//			String pincode=input[3];
//
//
//		}
//		}
		

		
	}

}
