package enums;

public enum Symptoms {
   COUGH,COLD,FEVER;
}
