package enums;

public enum RiskPercentage {

	RISK_0,RISK_1,RISK_2,RISK_3;
}
