package enums;

public enum ResultType {
POSITIVE,NEGATIVE;
}
