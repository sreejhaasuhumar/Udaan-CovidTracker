package enums;

public enum ZoneType {
	 GREEN,ORANGE,RED;
}
