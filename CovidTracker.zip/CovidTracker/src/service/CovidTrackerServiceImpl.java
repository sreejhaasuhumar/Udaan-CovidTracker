package service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import entity.HealthWorkers;
import entity.IDGenerator;
import entity.Results;
import entity.User;
import enums.ResultType;
import enums.RiskPercentage;
import enums.Symptoms;
import enums.ZoneType;

public class CovidTrackerServiceImpl implements CovidTrackerService {

	Map<Long,String> userMap;
	Map<Long,String> adminMap;
	Map<String,RiskPercentage> riskMap;
	Map<Long,List<String>> zoneMap;


	
	public CovidTrackerServiceImpl() {
		userMap=new HashMap<>();
		adminMap=new HashMap<>();
		riskMap=new HashMap<>();
		zoneMap=new HashMap<>();
	}
	
		
	
	@Override
	public User registerUser(String userName,String phoneNo,String pincode)
	{
		User user=null;
		try {
		if(userMap.containsValue(userName))
		{
			throw new Exception("User already exists");
		}
		
		Long userId=IDGenerator.getId();
		user=new User();
		user.setUserId(userId);
		user.setName(userName);
		user.setMobileNo(phoneNo);
		user.setPincode(pincode);
		userMap.put(userId, userName);
		}
		catch(Exception e)
		{
			e.printStackTrace();			
		}
		
		return user;
		
	}
	
	@Override
    public HealthWorkers registerAdmin(String userName,String phoneNo,String pincode)
    {  
		HealthWorkers admin=null;
		try {
		if(adminMap.containsValue(userName))
		{
			throw new Exception("Health worker already exists");
		}
		
		Long userId=IDGenerator.getId();
		admin=new HealthWorkers();
		admin.setUserId(userId);
		admin.setName(userName);
		admin.setMobileNo(phoneNo);
		admin.setPincode(pincode);
		adminMap.put(userId, userName);
		}
		catch(Exception e)
		{
			e.printStackTrace();			
		}
		
		return admin;
		
    }
	
	@Override
    public RiskPercentage selfAssessment(String userName,List<Symptoms> symptoms,boolean travelHistory,boolean isInContact) throws Exception
    {
		
		RiskPercentage type=null;
		ZoneType zoneType=null;
		List<String> list=new ArrayList<>();
		if(!userMap.containsValue(userName))
		{
			throw new Exception("user doesnt exists");
		}
		
		if(symptoms.size()==0 && !travelHistory && !isInContact)
		{
			type= RiskPercentage.RISK_0;
			
		}else if(symptoms.size()==1 && (travelHistory || isInContact))
		{
			type= RiskPercentage.RISK_1;
		}else if(symptoms.size()==2 && (travelHistory || isInContact))
		{
			type= RiskPercentage.RISK_2;
		}else if(symptoms.size()>2 && (travelHistory || isInContact))
		{
			type= RiskPercentage.RISK_3;
		}
		list.add(userName);
		
		riskMap.put(userName, type);
		Long count=0L;
		count=IDGenerator.getId();
		zoneMap.put(count,list);
		return type;	
    		
    }
	
	@Override
	public boolean updateCovidResult(Long userId,Long admiId,ResultType type) throws Exception
	{
		Results result=null;
		boolean updated=false;
		if(!userMap.containsKey(userId))
		{
			throw new Exception("user doesnt exists");
		}
		else if(!adminMap.containsKey(admiId))
		{
			throw new Exception("Health worker doesnt exists");
		}else
		{
			result=new Results(userId,admiId,type);
			updated=false;
			
		}
		
		return updated;
		
		
	}



	@Override
	public ZoneType getZoneInfo(String pincode) {
		// TODO Auto-generated method stub
		return null;
	}



	

}
