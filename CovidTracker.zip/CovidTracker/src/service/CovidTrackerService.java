package service;

import java.util.List;

import entity.HealthWorkers;
import entity.User;
import enums.ResultType;
import enums.RiskPercentage;
import enums.Symptoms;
import enums.ZoneType;

public interface CovidTrackerService {
	
	public User registerUser(String userName,String phoneNo,String pincode);
    public RiskPercentage selfAssessment(String userName,List<Symptoms> symptoms,boolean travelHistory,boolean isInContact) throws Exception;
    public HealthWorkers registerAdmin(String userName,String phoneNo,String pincode);
    public boolean updateCovidResult(Long userId,Long admiId,ResultType type) throws Exception;
    public ZoneType getZoneInfo(String pincode);
}
